#!/bin/bash

. constant.sh	

echo $1

cd ./kafka/config

echo -e "tickTime=2000\ninitLimit=5\nsyncLimit=2\nserver.1=${NODE1_IP}:${ZOOKEEPER_PORT1}\nserver.2=${NODE2_IP}:${ZOOKEEPER_PORT2}\nserver.3=${NODE3_IP}:${ZOOKEEPER_PORT3}" >> zookeeper.properties

cp zookeeper.properties zookeeper-$1.properties

sudo sed -i 's/dataDir=\/tmp\/zookeeper/dataDir=\/home\/SYSVNPORTAL\/notification-services\/logs\/zookeeper-'$1'/g' zookeeper-$1.properties

sudo sed -i 's/zookeeper.connect=localhost:2181/zookeeper.connect='${NODE1_IP}':2181,'$NODE2_IP':2181,'$NODE3_IP':2181/g' server.properties

cp server.properties server-$1.properties

sudo sed -i 's/broker.id=0/broker.id='$1'/g' server-$1.properties

sudo sed -i 's/#listeners=PLAINTEXT:\/\/:9092/listeners=PLAINTEXT:\/\/localhost:9091/g' server-$1.properties

sudo sed -i 's/log.dirs=\/tmp\/kafka-logs/log.dirs=\/home\/SYSVNPORTAL\/notification-services\/logs\/server-'$1'/g' server-$1.properties

cd /home/SYSVNPORTAL/notification-services/logs

if [ ! -d "zookeeper-$1" ]; then
	sudo mkdir zookeeper-$1
    sudo chown $USER zookeeper-$1
fi

echo $1 > zookeeper-$1/myid

cd ../script/kafka

bin/zookeeper-server-start.sh -daemon config/zookeeper-$1.properties

bin/kafka-server-start.sh -daemon config/server-$1.properties

bin/kafka-topics.sh --create --bootstrap-server ${NODE1_IP}:9091,${NODE2_IP}:9091,${NODE3_IP}:9091 --replication-factor 2 --partitions 2 --topic NOTIFICATION_MY_SALES
