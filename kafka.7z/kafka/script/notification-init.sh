#!/bin/bash

sudo cp ../systemd/notification.service /etc/systemd/system/
sudo systemctl enable notification
sudo systemctl start notification
